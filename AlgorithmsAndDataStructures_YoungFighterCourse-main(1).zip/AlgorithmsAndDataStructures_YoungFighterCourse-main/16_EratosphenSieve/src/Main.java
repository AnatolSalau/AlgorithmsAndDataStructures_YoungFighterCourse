public class Main {
    public static void main (String[] args) {
    EratosphenSieve eratosphenSieve = new EratosphenSieve(30);
    eratosphenSieve.insertSieveBool();
    eratosphenSieve.printSieveBool();
    }
}
