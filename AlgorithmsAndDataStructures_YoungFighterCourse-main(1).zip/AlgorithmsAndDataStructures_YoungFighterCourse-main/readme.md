# Courses from YouTube, channel: Тимофей Хирьянов
# Курс молодого бойца МФТИ
link: https://www.youtube.com/playlist?list=PLRDzFCPr95fLjzcv6nNdjMu_9RcZgIM9U